var searchData=
[
  ['getting_20started_781',['Getting started',['../quick_guide.html',1,'']]]
];
